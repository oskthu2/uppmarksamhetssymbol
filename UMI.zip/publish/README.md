# Uppmärksamhetssignal — vektorbibliotek

Ett SVG-baserat bibliotek för den svenska **Uppmärksamhetssignalen** med 7 oberoende fält som kan tändas och släckas dynamiskt.

## Fältkoder

Symbolen har sju fält som följer den officiella svenska namnkonventionen:

| Kod | Fält | Position |
|-----|------|----------|
| `1` | Toppblock | Övre delen av utropstecknet |
| `0` | Ränder | Mitten av utropstecknet |
| `4` | Punkt | Botten av utropstecknet |
| `2` | Nordost (NE) | Övre höger pentagon |
| `3` | Sydost (SE) | Nedre höger pentagon |
| `5` | Sydväst (SW) | Nedre vänster pentagon |
| `6` | Nordväst (NW) | Övre vänster pentagon |

Filer namnges enligt vilka fält som är tända, t.ex.:
- `Signal` — inga fält tända
- `Signal.014` — utropstecknet (livshotande överkänslighet)
- `Signal.25` — allvarlig sjukdom + smitta
- `Signal.0123456` — alla fält tända

## Versioner

- **v1** — Original (4 streck, ljus laxröd prick, ljusare gul). Komponent: `<UmiSymbol>`, builder: `umiSvgString()`.
- **v2** — Socialstyrelsens anvisning (3 streck, röd prick, varmare senapsgul). Komponent: `<UmiSymbolV2>`, builder: `umiSvgStringV2()`.

Båda har samma fältkoder och API.

## Filer

- `index.html` — interaktivt gränssnitt: live-editor med versionsväxlare (v1/v2), bibliotek med alla 128 kombinationer, sök, ladda ner SVG
- `symbol.jsx` — `<UmiSymbol>` (v1) + `umiSvgString()`
- `symbol-v2.jsx` — `<UmiSymbolV2>` (v2) + `umiSvgStringV2()`
- `app.jsx` — UI-logik
- `tweaks-panel.jsx` — UI-stödkomponenter
- `index-standalone.html` — komplett, fristående version (en fil, fungerar offline)

## Användning i din egen app

```jsx
// React — v1 (original)
<UmiSymbol active="014" size={120} />
<UmiSymbol active={[0, 1, 4]} size={120} />

// React — v2 (Socialstyrelsen)
<UmiSymbolV2 active="014" size={120} />

// Statisk SVG-sträng
const svgV1 = umiSvgString({ active: "25" });
const svgV2 = umiSvgStringV2({ active: "25" });

// Egna färger per fält
<UmiSymbol active="0123456" colors={{ "0": "#000", "4": "#FF6B6B" }} />
```

## Publicera på GitHub Pages

1. Gå till **Settings → Pages** i repot
2. Välj **Source: Deploy from a branch → main → / (root)**
3. Spara — sidan blir tillgänglig på `https://<user>.github.io/uppmarksamhetssymbol/`

## Geometri

Alla path-data är härledda från originalkällan (PowerPoint-vektorgrafik). ViewBox: `0 0 2010 1983`. Symbolens kontur använder `fill-rule="evenodd"`, fälten är separata `<path>`-element med `data-field`-attribut för enkel CSS/JS-styrning.

## Licens

Symbolen Uppmärksamhetssignal är ett standardiserat vårdsymbol; denna implementation är fri att använda.
