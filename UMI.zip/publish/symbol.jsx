// UmiSymbol - Uppmärksamhetssignal SVG component
// Field codes (matches the official Swedish naming convention):
//   1 = top vertical bar  (top of exclamation mark)
//   0 = horizontal stripes (middle of exclamation mark)
//   4 = bottom dot         (period of exclamation mark)
//   2 = NE corner wedge    (allvarlig sjukdom / serious illness)
//   3 = SE corner wedge
//   5 = SW corner wedge    (smitta / infection)
//   6 = NW corner wedge
// "014" = full exclamation mark = livshotande överkänslighet (life-threatening allergy)
// "25" = NE + SW = serious illness + infection

const UMI_COLORS = {
  outline: "#1a1a1a",
  background: "#ffffff",
  off: "#ffffff",        // unlit field color (white)
  red:   "#B60606",
  blue:  "#05598A",
  yellow:"#E1A100",
  // optional palette mapping per field
};

// Default colour per field (matches reference imagery)
const UMI_FIELD_COLOR = {
  0: "#B60606", // stripes
  1: "#B60606", // top bar
  2: "#B60606", // NE
  3: "#05598A", // SE
  4: "#FA7070", // dot (lighter salmon-red, matches reference)
  5: "#E1A100", // SW
  6: "#B60606", // NW
};

// Geometry (viewBox 2010 x 1983) — derived from the source PPTX vector data.
// Outline path (border of the Star of Life - drawn as outer minus inner via evenodd)
const UMI_OUTLINE_OUTER = "M 1627 991 L 2010 1204 L 1718 1733 L 1333 1519 L 1333 1983 L 677 1983 L 677 1519 L 292 1733 L 0 1204 L 383 991 L 0 778 L 292 248 L 677 463 L 677 0 L 1333 0 L 1333 463 L 1718 249 L 2010 778 Z";
const UMI_OUTLINE_INNER = "M 1556 991 L 1964 764 L 1704 295 L 1299 520 L 1299 34 L 711 34 L 711 520 L 305 295 L 46 764 L 453 991 L 46 1218 L 305 1687 L 711 1461 L 711 1949 L 1299 1949 L 1299 1461 L 1704 1687 L 1964 1217 Z";

// Field paths
// Wedges are pentagons: 4 corners of the star-point + a triangular point reaching
// inward toward the center hexagon. The inner tip sits a bit short of the center,
// matching the reference imagery.
const UMI_FIELDS = {
  // Pentagon wedges — inset with shorter inner tips so they don't touch the centre.
  // NW
  6: "M 700 545 L 330 340 L 90 770 L 480 970 L 700 880 Z",
  // NE
  2: "M 1310 545 L 1680 340 L 1920 770 L 1530 970 L 1310 880 Z",
  // SW
  5: "M 480 1012 L 90 1212 L 330 1642 L 700 1437 L 700 1102 Z",
  // SE
  3: "M 1530 1012 L 1920 1212 L 1680 1642 L 1310 1437 L 1310 1102 Z",
  // Top vertical bar — inset 25 units on each side, top, and bottom
  1: "M 736 60 L 1274 60 L 1274 740 L 736 740 Z",
  // Horizontal stripes — same width as the top bar (711..1299), thicker bars
  // with wider gaps so they fill more vertical space (last bar near the dot).
  // Horizontal stripes — inset same as top bar (736..1274), keep gaps
  0: [
    "M 736 820 L 1274 820 L 1274 890 L 736 890 Z",
    "M 736 950 L 1274 950 L 1274 1020 L 736 1020 Z",
    "M 736 1080 L 1274 1080 L 1274 1150 L 736 1150 Z",
    "M 736 1210 L 1274 1210 L 1274 1280 L 736 1280 Z",
  ].join(" "),
  // Bottom dot — raised so it has clear padding from the bottom outline
  4: "M 740 1640 a 265 265 0 1 0 530 0 a 265 265 0 1 0 -530 0 Z",
};

// Field labels (Swedish names, abbreviated)
const UMI_FIELD_LABELS = {
  0: "Stripes (mid)",
  1: "Top bar",
  2: "Nordost (NE)",
  3: "Sydost (SE)",
  4: "Bottom dot",
  5: "Sydväst (SW)",
  6: "Nordväst (NW)",
};

/**
 * UmiSymbol — render the Uppmärksamhetssignal symbol.
 *
 * Props:
 *   active:     array of field codes (digits 0-6) that are lit, e.g. [0,1,4] or "014"
 *   size:       pixel size (square). Default 200.
 *   colors:     {[fieldCode]: cssColor}. Override default field colors.
 *   offColor:   color for unlit fields. Default 'transparent' (invisible).
 *   outlineColor: color for the star border. Default '#1a1a1a'.
 *   showOff:    if true, render unlit fields as ghosts using offColor. Default false.
 *   onFieldClick: (code) => void. Click handler for individual fields.
 *   className, style: usual passthrough.
 */
function UmiSymbol({
  active = [],
  size = 200,
  colors = {},
  offColor = "#ffffff",
  outlineColor = "#1a1a1a",
  showOff = false,
  onFieldClick = null,
  className = "",
  style = {},
  title = "Uppmärksamhetssignal",
}) {
  // normalise `active` — accept array, string "014", or Set
  const activeSet = React.useMemo(() => {
    if (active instanceof Set) return new Set([...active].map(String));
    if (typeof active === "string") return new Set(active.split(""));
    return new Set((active || []).map(String));
  }, [active]);

  const colorOf = (code) => colors[code] || UMI_FIELD_COLOR[code];

  return (
    <svg
      className={className}
      style={style}
      width={size}
      height={size * (1983 / 2010)}
      viewBox="0 0 2010 1983"
      xmlns="http://www.w3.org/2000/svg"
      role="img"
      aria-label={title}
    >
      <title>{title}</title>

      {/* Solid white background fill — covers the full inner area of the star
          so no underlying content bleeds through gaps between fields. */}
      <path
        d={UMI_OUTLINE_INNER}
        fill="#ffffff"
        pointerEvents="none"
      />

      {/* Field 6 - NW wedge */}
      <path
        data-field="6"
        d={UMI_FIELDS[6]}
        fill={activeSet.has("6") ? colorOf("6") : (showOff ? offColor : "transparent")}
        onClick={onFieldClick ? () => onFieldClick("6") : undefined}
        style={{ cursor: onFieldClick ? "pointer" : undefined }}
      />
      {/* Field 2 - NE wedge */}
      <path
        data-field="2"
        d={UMI_FIELDS[2]}
        fill={activeSet.has("2") ? colorOf("2") : (showOff ? offColor : "transparent")}
        onClick={onFieldClick ? () => onFieldClick("2") : undefined}
        style={{ cursor: onFieldClick ? "pointer" : undefined }}
      />
      {/* Field 5 - SW wedge */}
      <path
        data-field="5"
        d={UMI_FIELDS[5]}
        fill={activeSet.has("5") ? colorOf("5") : (showOff ? offColor : "transparent")}
        onClick={onFieldClick ? () => onFieldClick("5") : undefined}
        style={{ cursor: onFieldClick ? "pointer" : undefined }}
      />
      {/* Field 3 - SE wedge */}
      <path
        data-field="3"
        d={UMI_FIELDS[3]}
        fill={activeSet.has("3") ? colorOf("3") : (showOff ? offColor : "transparent")}
        onClick={onFieldClick ? () => onFieldClick("3") : undefined}
        style={{ cursor: onFieldClick ? "pointer" : undefined }}
      />
      {/* Field 1 - top vertical bar */}
      <path
        data-field="1"
        d={UMI_FIELDS[1]}
        fill={activeSet.has("1") ? colorOf("1") : (showOff ? offColor : "transparent")}
        onClick={onFieldClick ? () => onFieldClick("1") : undefined}
        style={{ cursor: onFieldClick ? "pointer" : undefined }}
      />
      {/* Field 0 - stripes */}
      <path
        data-field="0"
        d={UMI_FIELDS[0]}
        fill={activeSet.has("0") ? colorOf("0") : (showOff ? offColor : "transparent")}
        onClick={onFieldClick ? () => onFieldClick("0") : undefined}
        style={{ cursor: onFieldClick ? "pointer" : undefined }}
      />
      {/* Field 4 - bottom dot */}
      <path
        data-field="4"
        d={UMI_FIELDS[4]}
        fill={activeSet.has("4") ? colorOf("4") : (showOff ? offColor : "transparent")}
        onClick={onFieldClick ? () => onFieldClick("4") : undefined}
        style={{ cursor: onFieldClick ? "pointer" : undefined }}
      />

      {/* Star outline border (drawn last so it sits on top) */}
      <path
        d={UMI_OUTLINE_OUTER + " " + UMI_OUTLINE_INNER}
        fill={outlineColor}
        fillRule="evenodd"
        pointerEvents="none"
      />
    </svg>
  );
}

// Build a static SVG string (no React) for export/download.
function umiSvgString({ active = [], colors = {}, outlineColor = "#1a1a1a", showOff = false, offColor = "#ffffff", size = null }) {
  const set = new Set((typeof active === "string" ? active.split("") : active).map(String));
  const colorOf = (c) => colors[c] || UMI_FIELD_COLOR[c];
  const fill = (code) => set.has(code) ? colorOf(code) : (showOff ? offColor : "none");
  const sizeAttrs = size ? ` width="${size}" height="${(size * 1983 / 2010).toFixed(2)}"` : "";
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 2010 1983"${sizeAttrs}>
  <title>Uppmärksamhetssignal ${set.size ? [...set].sort().join("") : "(blank)"}</title>
  <path d="${UMI_OUTLINE_INNER}" fill="#ffffff"/>
  <path data-field="6" d="${UMI_FIELDS[6]}" fill="${fill("6")}"/>
  <path data-field="2" d="${UMI_FIELDS[2]}" fill="${fill("2")}"/>
  <path data-field="5" d="${UMI_FIELDS[5]}" fill="${fill("5")}"/>
  <path data-field="3" d="${UMI_FIELDS[3]}" fill="${fill("3")}"/>
  <path data-field="1" d="${UMI_FIELDS[1]}" fill="${fill("1")}"/>
  <path data-field="0" d="${UMI_FIELDS[0]}" fill="${fill("0")}"/>
  <path data-field="4" d="${UMI_FIELDS[4]}" fill="${fill("4")}"/>
  <path d="${UMI_OUTLINE_OUTER} ${UMI_OUTLINE_INNER}" fill="${outlineColor}" fill-rule="evenodd"/>
</svg>`;
}

// Export to global scope so other Babel scripts can use these
Object.assign(window, {
  UmiSymbol, umiSvgString,
  UMI_COLORS, UMI_FIELD_COLOR, UMI_FIELDS, UMI_FIELD_LABELS,
  UMI_OUTLINE_OUTER, UMI_OUTLINE_INNER,
});
