// Main UI logic for the Uppmärksamhetssignal library

const { useState, useMemo, useEffect, useRef } = React;

// All 128 possible combinations (2^7) — but the standard naming uses sorted digits
function generateAllCodes() {
  const codes = [];
  for (let mask = 0; mask < 128; mask++) {
    const digits = [];
    for (let i = 0; i < 7; i++) {
      if (mask & (1 << i)) digits.push(String(i));
    }
    digits.sort();
    codes.push(digits.join(""));
  }
  return codes;
}
const ALL_CODES = generateAllCodes();

const COMMON_SIGNALS = [
  { code: "",        label: "Tom (Signal)",       desc: "Inget fält tänt" },
  { code: "014",     label: "Utropstecken (014)", desc: "Livshotande överkänslighet" },
  { code: "25",      label: "Diagonal (25)",      desc: "Allvarlig sjukdom + smitta" },
  { code: "36",      label: "Motdiagonal (36)",   desc: "Nordväst + sydost" },
  { code: "0123456", label: "Alla tända",         desc: "Komplett signal" },
];

function fieldsFromCode(code) {
  return new Set((code || "").split(""));
}

function App() {
  const [active, setActive] = useState(new Set(["0", "1", "4"])); // start with utropstecken
  const [version, setVersion] = useState("v2"); // "v1" | "v2"
  const [codeTab, setCodeTab] = useState("svg");
  const [search, setSearch] = useState("");
  const [toast, setToast] = useState("");

  // Pick the correct symbol component / colors / svg builder for the chosen version
  const Symbol = version === "v2" ? UmiSymbolV2 : UmiSymbol;
  const fieldColors = version === "v2" ? UMI_FIELD_COLOR_V2 : UMI_FIELD_COLOR;
  const fieldLabels = version === "v2" ? UMI_FIELD_LABELS_V2 : UMI_FIELD_LABELS;
  const svgBuilder = version === "v2" ? umiSvgStringV2 : umiSvgString;

  const code = useMemo(() => [...active].sort().join(""), [active]);
  const signalName = code === "" ? "Signal" : "Signal." + code;

  function toggleField(f) {
    setActive(prev => {
      const next = new Set(prev);
      if (next.has(f)) next.delete(f); else next.add(f);
      return next;
    });
  }
  function setFromCode(c) { setActive(fieldsFromCode(c)); }

  function showToast(msg) {
    setToast(msg);
    setTimeout(() => setToast(""), 1800);
  }

  // Wire up to existing DOM scaffolding
  // Preview
  const previewRef = useRef(null);
  useEffect(() => {
    const stage = document.getElementById("preview-stage");
    if (!stage || !previewRef.current) return;
    stage.innerHTML = "";
    stage.appendChild(previewRef.current);
  }, []);

  // Update meta in scaffold
  useEffect(() => {
    document.getElementById("signal-name").textContent = signalName;
    document.getElementById("active-fields").textContent = code === "" ? "(inga)" : code;
    document.getElementById("active-count").textContent = active.size;
  }, [code, active.size, signalName]);

  // Search
  useEffect(() => {
    const inp = document.getElementById("search");
    const clr = document.getElementById("clear-filter");
    const handler = (e) => setSearch(e.target.value);
    inp.addEventListener("input", handler);
    clr.addEventListener("click", () => { inp.value = ""; setSearch(""); });
    return () => inp.removeEventListener("input", handler);
  }, []);

  // Filtered codes
  const filteredCodes = useMemo(() => {
    if (!search.trim()) return ALL_CODES;
    const q = search.trim().replace(/[^0-6]/g, "").split("").sort().join("");
    if (!q) return ALL_CODES;
    return ALL_CODES.filter(c => c === q);
  }, [search]);

  // Update match-count
  useEffect(() => {
    document.getElementById("match-count").textContent =
      filteredCodes.length === ALL_CODES.length
        ? `${ALL_CODES.length} symboler`
        : `${filteredCodes.length} träff${filteredCodes.length === 1 ? "" : "ar"}`;
  }, [filteredCodes.length]);

  // Code panel content
  const svgString = useMemo(() => svgBuilder({ active: code, size: null }), [code, svgBuilder]);
  const componentName = version === "v2" ? "UmiSymbolV2" : "UmiSymbol";
  const builderName = version === "v2" ? "umiSvgStringV2" : "umiSvgString";
  const reactSnippet = useMemo(
    () => `<${componentName} active="${code}" size={200} />`,
    [code, componentName]
  );
  const jsSnippet = useMemo(
    () => `// Build static SVG string\nconst svg = ${builderName}({ active: "${code}" });\ndocument.body.innerHTML = svg;`,
    [code, builderName]
  );
  const codeText = codeTab === "svg" ? svgString : (codeTab === "react" ? reactSnippet : jsSnippet);

  useEffect(() => {
    document.getElementById("code-display").textContent = codeText;
    document.querySelectorAll(".code-tab").forEach(b => {
      b.classList.toggle("active", b.dataset.tab === codeTab);
      b.onclick = () => setCodeTab(b.dataset.tab);
    });
  }, [codeText, codeTab]);

  function downloadSvg() {
    const blob = new Blob([svgString], { type: "image/svg+xml" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${signalName}.svg`;
    a.click();
    URL.revokeObjectURL(url);
    showToast(`Laddade ner ${signalName}.svg`);
  }
  function copySvg() {
    navigator.clipboard.writeText(svgString).then(() => showToast("SVG-kod kopierad"));
  }
  function copyCode() {
    navigator.clipboard.writeText(codeText).then(() => showToast("Kopierat"));
  }

  function downloadAll() {
    // Simple approach: produce a single multi-symbol HTML for printing/exporting,
    // OR generate a zip via dynamic JSZip. Without external libs, build a manifest HTML.
    // We'll generate one SVG file at a time via concat into a single .svg sprite + manifest.
    const sprite = ALL_CODES.map(c => {
      const inner = svgBuilder({ active: c }).replace(/<\?xml[^>]*\?>/, "")
        .replace(/<svg [^>]*>/, `<symbol id="signal-${c || "blank"}" viewBox="0 0 2010 1983">`)
        .replace(/<\/svg>/, "</symbol>");
      return inner;
    }).join("\n");
    const spriteSvg = `<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" style="display:none">
${sprite}
</svg>`;
    const blob = new Blob([spriteSvg], { type: "image/svg+xml" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `uppmarksamhetssignal-${version}-sprite.svg`;
    a.click();
    URL.revokeObjectURL(url);
    showToast("Sprite med 128 symboler nedladdad");
  }

  // Wire download buttons in the static DOM
  useEffect(() => {
    const dlAll = document.getElementById("dl-all");
    dlAll.onclick = downloadAll;
  }, []);

  // Toast
  useEffect(() => {
    const el = document.getElementById("toast");
    el.textContent = toast;
    el.classList.toggle("show", !!toast);
  }, [toast]);

  return (
    <>
      {/* Preview SVG (rendered inside #preview-stage via portal-like mount above) */}
      <div ref={previewRef} style={{ width: "100%", display: "flex", justifyContent: "center" }}>
        <Symbol
          active={[...active]}
          size={300}
          showOff={true}
          offColor="#ffffff"
          onFieldClick={toggleField}
          style={{ filter: "drop-shadow(0 2px 4px rgba(0,0,0,0.06))" }}
        />
      </div>

      {/* Controls portal: render into #controls */}
      <ControlsPortal>
        <h3>Version</h3>
        <div className="version-row">
          <button
            className={`version-chip ${version === "v1" ? "current" : ""}`}
            onClick={() => setVersion("v1")}
          >
            <span className="v-num">v1</span>
            <span className="v-desc">Original (4 streck, lax-prick)</span>
          </button>
          <button
            className={`version-chip ${version === "v2" ? "current" : ""}`}
            onClick={() => setVersion("v2")}
          >
            <span className="v-num">v2</span>
            <span className="v-desc">Socialstyrelsen (3 streck, röd prick)</span>
          </button>
        </div>
        <h3>Fält</h3>
        <div className="field-grid">
          {["1", "0", "4", "2", "3", "5", "6"].map(f => (
            <button
              key={f}
              className={`field-toggle ${active.has(f) ? "on" : ""}`}
              onClick={() => toggleField(f)}
              style={{ color: fieldColors[f] }}
            >
              <span className={`swatch ${active.has(f) ? "lit" : ""}`} />
              <span className="lbl">
                <span className="num">{f}</span>
                <span className="name">{fieldLabels[f]}</span>
              </span>
            </button>
          ))}
        </div>
        <h3>Kombinationer</h3>
        <div className="preset-row">
          {["", "014", "25", "36", "0123456"].map(c => (
            <button
              key={c || "blank"}
              className={`preset-chip ${c === code ? "current" : ""}`}
              onClick={() => setFromCode(c)}
            >
              {c === "" ? "Tom" : c}
            </button>
          ))}
          <button className="preset-chip" onClick={() => setActive(new Set())}>Rensa</button>
          <button className="preset-chip" onClick={() => setActive(new Set("0123456".split("")))}>Allt</button>
        </div>
        <div className="actions">
          <button className="btn primary" onClick={downloadSvg}>↓ Ladda ner SVG</button>
          <button className="btn" onClick={copySvg}>Kopiera SVG</button>
          <button className="btn" onClick={copyCode}>Kopiera kod</button>
        </div>
      </ControlsPortal>

      {/* Gallery */}
      <GalleryPortal>
        {filteredCodes.map(c => (
          <button
            key={c || "blank"}
            className={`tile ${c === code ? "active" : ""}`}
            onClick={() => setFromCode(c)}
            title={c === "" ? "Signal (tom)" : "Signal." + c}
          >
            <Symbol active={c} size={70} showOff={true} offColor="#ffffff" />
            <span className="code">{c === "" ? "—" : c}</span>
          </button>
        ))}
      </GalleryPortal>

      {/* Common signals sidebar */}
      <CommonPortal>
        {COMMON_SIGNALS.map(s => (
          <button
            key={s.code || "blank"}
            className="field-toggle"
            style={{ width: "100%", textAlign: "left" }}
            onClick={() => setFromCode(s.code)}
          >
            <Symbol active={s.code} size={36} showOff={true} offColor="#ffffff" />
            <span className="lbl">
              <span className="name" style={{ fontWeight: 600 }}>{s.label}</span>
              <span className="num" style={{ fontSize: 11, color: "var(--ink-3)" }}>{s.desc}</span>
            </span>
          </button>
        ))}
      </CommonPortal>
    </>
  );
}

// Tiny portal helpers
function ControlsPortal({ children }) {
  const [el, setEl] = useState(null);
  useEffect(() => { setEl(document.getElementById("controls")); }, []);
  return el ? ReactDOM.createPortal(children, el) : null;
}
function GalleryPortal({ children }) {
  const [el, setEl] = useState(null);
  useEffect(() => { setEl(document.getElementById("gallery")); }, []);
  return el ? ReactDOM.createPortal(children, el) : null;
}
function CommonPortal({ children }) {
  const [el, setEl] = useState(null);
  useEffect(() => { setEl(document.getElementById("common-signals")); }, []);
  return el ? ReactDOM.createPortal(children, el) : null;
}

// Mount
const mountEl = document.createElement("div");
document.body.appendChild(mountEl);
ReactDOM.createRoot(mountEl).render(<App />);
