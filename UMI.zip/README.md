# Uppmärksamhetssignal — vektorbibliotek

Ett SVG-baserat bibliotek för den svenska **Uppmärksamhetssignalen** med 7 oberoende fält som kan tändas och släckas dynamiskt.

## Fältkoder

Symbolen har sju fält som följer den officiella svenska namnkonventionen:

| Kod | Fält | Position |
|-----|------|----------|
| `1` | Toppblock | Övre delen av utropstecknet |
| `0` | Ränder | Mitten av utropstecknet |
| `4` | Punkt | Botten av utropstecknet |
| `2` | Nordost (NE) | Övre höger pentagon |
| `3` | Sydost (SE) | Nedre höger pentagon |
| `5` | Sydväst (SW) | Nedre vänster pentagon |
| `6` | Nordväst (NW) | Övre vänster pentagon |

Filer namnges enligt vilka fält som är tända, t.ex.:
- `Signal` — inga fält tända
- `Signal.014` — utropstecknet (livshotande överkänslighet)
- `Signal.25` — allvarlig sjukdom + smitta
- `Signal.0123456` — alla fält tända

## Filer

- `index.html` — interaktivt gränssnitt: live-editor, bibliotek med alla 128 kombinationer, sök, ladda ner SVG
- `symbol.jsx` — `<UmiSymbol>` React-komponent + `umiSvgString()` hjälpare
- `app.jsx` — UI-logik
- `tweaks-panel.jsx` — UI-stödkomponenter
- `index-standalone.html` — komplett, fristående version (en fil, fungerar offline)

## Användning i din egen app

```jsx
// React
<UmiSymbol active="014" size={120} />
<UmiSymbol active={[0, 1, 4]} size={120} />

// Statisk SVG-sträng
const svg = umiSvgString({ active: "25" });
document.body.innerHTML = svg;

// Egna färger per fält
<UmiSymbol active="0123456" colors={{ "0": "#000", "4": "#FF6B6B" }} />
```

## Publicera på GitHub Pages

1. Gå till **Settings → Pages** i repot
2. Välj **Source: Deploy from a branch → main → / (root)**
3. Spara — sidan blir tillgänglig på `https://<user>.github.io/uppmarksamhetssymbol/`

## Geometri

Alla path-data är härledda från originalkällan (PowerPoint-vektorgrafik). ViewBox: `0 0 2010 1983`. Symbolens kontur använder `fill-rule="evenodd"`, fälten är separata `<path>`-element med `data-field`-attribut för enkel CSS/JS-styrning.

## Licens

Symbolen Uppmärksamhetssignal är ett standardiserat vårdsymbol; denna implementation är fri att använda.
